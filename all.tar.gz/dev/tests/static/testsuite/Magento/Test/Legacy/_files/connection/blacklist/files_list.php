<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

/**
 * Files that excluded from results
 */
return [
    '/app/code/Magento/AdvancedPricingImportExport/Test/Unit/Model/Export/AdvancedPricingTest.php',
    '/app/code/Magento/AdvancedPricingImportExport/Model/Export/AdvancedPricing.php',
    '/app/code/Magento/CatalogImportExport/Test/Unit/Model/Export/ProductTest.php',
    '/app/code/Magento/CatalogImportExport/Model/Export/Product.php',
    '/app/code/Magento/EncryptionKey/Controller/Adminhtml/Crypt/Key/Index.php',
    '/app/code/Magento/EncryptionKey/Model/Resource/Key/Change.php',
  //example  '/app/code/Magento/Backend/Model/View.php',
];
