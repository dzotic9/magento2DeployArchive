<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
return [
    'dev/tests/static/testsuite/Magento/Test/Legacy/ObsoleteCodeTest.php',
    'dev/tests/static/testsuite/Magento/Test/Integrity/ClassesTest.php',
    'dev/tests/static/testsuite/Magento/Test/Legacy/_files/*obsolete*.php'
];
