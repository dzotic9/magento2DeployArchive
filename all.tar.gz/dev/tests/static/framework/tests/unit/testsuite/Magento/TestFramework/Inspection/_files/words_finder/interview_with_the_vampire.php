<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
echo 'A man tells his epic life story: love, betrayal, loneliness, and hunger.';
