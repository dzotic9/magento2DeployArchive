<?php
/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

$rootDir = realpath(__DIR__ . '/../../../../../../../');
$testsBaseDir = realpath(__DIR__ . '/../../../../');

require_once $rootDir . '/app/bootstrap.php';
require_once $testsBaseDir . '/framework/autoload.php';
