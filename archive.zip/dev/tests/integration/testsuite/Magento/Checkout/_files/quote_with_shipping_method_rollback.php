<?php
/**
 * Rollback for quote_with_shipping_method.php fixture.
 *
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
require 'quote_with_address_saved_rollback.php';
