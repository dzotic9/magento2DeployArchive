<?php
/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

return [
    'mc_gross' => '100.00',
    'invoice' => '100000001',
    'payment_status' => 'Completed',
    'auth_status' => 'Completed',
    'mc_currency' => 'USD',
    'receiver_email' => 'merchant_2012050718_biz@example.com'
];
