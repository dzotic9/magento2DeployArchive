<?php
/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

return [
    'firstname' => 'guest',
    'lastname' => 'guest',
    'email' => 'customer@example.com',
    'street' => 'street',
    'city' => 'Los Angeles',
    'region' => 'CA',
    'postcode' => '1',
    'country_id' => 'US',
    'telephone' => '1'
];
