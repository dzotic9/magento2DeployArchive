<?php
/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\B\Model;

class Foo
{
    /**
     * @SuppressWarnings(PHPMD.UnusedLocalVariable)
     */
    public function foo()
    {
        $frameworkDependencies = new \Magento\Framework\B();
    }
}
