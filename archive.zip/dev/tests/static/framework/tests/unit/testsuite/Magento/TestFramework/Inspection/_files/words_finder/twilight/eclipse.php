<?php
/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
echo 'As a string of mysterious killings grips Seattle, Bella, whose high school graduation is fast approaching,
    is forced to choose between her love for vampire Edward and her friendship with demon Jacob.';
