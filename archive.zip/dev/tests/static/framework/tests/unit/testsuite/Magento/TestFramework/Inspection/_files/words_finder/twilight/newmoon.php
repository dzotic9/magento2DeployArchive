<?php
/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
echo 'Vampire Edward leaves Bella after an attack that nearly claimed her life, and in her depression she falls into
    yet another paranormal relationship - this time with demon Jacob Black.';
