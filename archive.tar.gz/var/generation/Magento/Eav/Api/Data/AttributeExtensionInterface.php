<?php
namespace Magento\Eav\Api\Data;

/**
 * ExtensionInterface class for @see \Magento\Eav\Api\Data\AttributeInterface
 */
interface AttributeExtensionInterface extends \Magento\Framework\Api\ExtensionAttributesInterface
{
}
