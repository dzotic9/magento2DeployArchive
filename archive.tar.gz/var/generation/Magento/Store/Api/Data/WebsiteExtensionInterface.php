<?php
namespace Magento\Store\Api\Data;

/**
 * ExtensionInterface class for @see \Magento\Store\Api\Data\WebsiteInterface
 */
interface WebsiteExtensionInterface extends \Magento\Framework\Api\ExtensionAttributesInterface
{
}
