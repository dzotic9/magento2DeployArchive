<?php
namespace Magento\Store\Api\Data;

/**
 * ExtensionInterface class for @see \Magento\Store\Api\Data\StoreInterface
 */
interface StoreExtensionInterface extends \Magento\Framework\Api\ExtensionAttributesInterface
{
}
